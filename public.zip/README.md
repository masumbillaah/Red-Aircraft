# Red Arrow Aircraft

### Live Website: [https://quirky-swanson-4c058b.netlify.app/](https://quirky-swanson-4c058b.netlify.app/)

This is a website for creating an aircraft management team. 
Here are some features. It is described below:

* Select your preferred pilot and crew
* Calculate total cost
* Get pilot and crew information
* Calculate total team members added
* Create custom aircraft Team

Best Regards \
Md. Rifat Islam